import java.io.FileInputStream;
		import java.io.FileNotFoundException;
		import java.io.FileOutputStream;
		import java.io.PrintWriter;
		import java.util.Scanner;

public class mp1 {

	public static void main(String[] args) throws FileNotFoundException { 
		
	
		Scanner scan = new Scanner (System.in);
		
	
		System.out.println("What is the key value?");
		int key = scan.nextInt();
		
		
		String ans = "";
		
		
		Scanner input = new Scanner (new FileInputStream("C:\\Users\\19803\\eclipse-workspace\\MakeupMp1\\src\\input1.txt"));
		
		while (input.hasNextLine()) {
		ans += input.nextLine() + "\n";
		}
		
		
		int ascii = 0;
		
		
		PrintWriter scanner = new PrintWriter (new FileOutputStream("C:\\Users\\19803\\eclipse-workspace\\MakeupMp1\\src\\input1.txt".replace(".txt", "_NEW")));
		
		
		for (char k : ans.toCharArray()) {
		
			if (Character.isAlphabetic(k)) {
		
				if ((k > 64) && (k < 91)) { 
					ascii = k + key;
		
					if (ascii >= 91) {
						ascii -= 26;
							}
					k = (char) ascii;
					}
		
				else if ((k > 96) && (k < 123)) { 
					ascii = k + key;
		
					if (ascii >= 123) {
						ascii -= 26;
						}
		
					k = (char) ascii;
				}
				}
		
					scanner.print(k);
		}
					scanner.close();
		}

	
	}

